export const plugins = {
  "@tailwindcss/postcss": {},
};
